var slide = new Array("./images/Artboard_2.jpg", "./images/Artboard_1.jpg");
var numero = 0;

function nextSlide(sens) {
    numero = numero + sens;
    if (numero > slide.length - 1)
        numero = 0;
    document.getElementById("slide").src = slide[numero];
}